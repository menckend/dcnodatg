# dcnodatg/__init__.py
"""Data Center Network on Demand - Arista to GNS3

This package has only one module/script:
    - 'dcnodatg': Does the deed
"""